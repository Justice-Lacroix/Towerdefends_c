// main.cpp

#include "Game.h"

int main() {
    justice::Game game;
    game.Start();

    // Voer de update uit nadat een toren is gekozen
    while (game.IsTorenGekozen()&& game.getIsGestart() ) {
        game.Update();
    }

    // Stop de game
    game.Stop();

    return 0;
}
