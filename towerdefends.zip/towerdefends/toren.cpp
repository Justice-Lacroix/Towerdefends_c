// toren.cpp
#include "toren.h"
#include <stdio.h>

toren::toren(std::string soort_vuurwapen, std::string tekst, int damage, int tijd_damage, int bereik, int level, int geld, int health)
    : soort_vuurwapen(soort_vuurwapen), tekst(tekst), damage(damage), tijd_damage(tijd_damage), bereik(bereik), level(level), geld(geld), health(health)
{
    // Andere constructorlogica, indien van toepassing
}

toren::~toren()
{
    // Voeg eventuele logica toe voor de destructor van de torenklasse
}
