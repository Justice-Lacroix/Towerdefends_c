#ifndef MONSTERS_H
#define MONSTERS_H

#include <string>
#include <iostream>
class monsters
{
public:
    monsters(int hp,bool leven,int speed);
     virtual void talk ()=0 ;
   virtual ~monsters();
protected:
    // de variabelen die een monster moet hebben
    //deze staan op protected omdat deze een keer worden meegegeven en erna nietmeer veranderbaar moeten zijn, ze kunnen eventueel ge get of geset worden
    int speed;
    int hp;
    bool leven;

};

#endif // MONSTERS_H
