#include <iostream>
#include <vector>
#include <toren.h>
#include <pijlenboogtoren.h>
#include <kanontoren.h>
#include "greenzombie.h"

using namespace std;

int main()
{
    std::vector<pijlenboogtoren> pijlenboogtorens;

    // Vector voor kanontorens
    std::vector<kanontoren> kanontorens;

    // Maak 5 pijlenboogtorens en voeg ze toe aan de vector
    for (int i = 0; i < 5; ++i) {
        pijlenboogtorens.push_back(pijlenboogtoren());
    }

    // Maak 5 kanontorens en voeg ze toe aan de vector
    for (int i = 0; i < 5; ++i) {
        kanontorens.push_back(kanontoren());
    }


    std::vector<greenzombie> zombieVector;

    // Populate the vector with 5 greenzombie objects
    for (int i = 0; i < 5; ++i) {
        zombieVector.push_back(greenzombie());
    }

    // Make the fourth zombie talk (assuming zero-based indexing)
    if (zombieVector.size() > 3) {
        zombieVector[3].talk();
    } else {
        std::cout << "Error: Not enough zombies in the vector." << std::endl;
    }

    // Roep de schietfunctie aan voor het tweede element in de vector van pijlenboogtorens
    pijlenboogtorens[1].schiet(3); // Bijvoorbeeld 3 keer schieten
 pijlenboogtorens[1].setSoortVuurwapen("scherpe pijl");
     pijlenboogtorens[1].schiet(3);
    // Voer andere operaties uit met de torens, indien nodig

    return 0;
}
