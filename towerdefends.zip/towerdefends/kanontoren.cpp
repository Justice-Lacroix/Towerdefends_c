// kanontoren.cpp
#include "kanontoren.h"
#include <iostream>

kanontoren::kanontoren() : toren("kanon", "vuur met kracht", 20, 2, 8, 1, 150, 20)
{
    // Constructorlogica voor kanontoren, indien van toepassing
}

kanontoren::~kanontoren()
{
    // Voeg eventuele logica toe voor de destructor van de kanontorenklasse
}

void kanontoren::schiet(int aantal)
{
    for (int i = 0; i < aantal; i++)
    {
        std::cout << soort_vuurwapen << std::endl;
    }
}
