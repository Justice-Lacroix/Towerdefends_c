#include "greenzombie.h"
#include <iostream>

// Constructor
greenzombie::greenzombie():monsters(100,true,50) {}

// Destructor
greenzombie::~greenzombie() {}

// Implementation of the talk method
void greenzombie::talk() {
    std::cout << "Green Zombie says: Braaains!" << std::endl;
}
