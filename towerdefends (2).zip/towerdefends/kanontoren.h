// kanontoren.h
#ifndef KANONTOREN_H
#define KANONTOREN_H

#include "toren.h"

class kanontoren : public toren
{
public:
    // Constructor met standaardwaarden voor attributen
    kanontoren();
    // Destructor
    ~kanontoren();
    void schiet(int aantal) override;
};

#endif // KANONTOREN_H
