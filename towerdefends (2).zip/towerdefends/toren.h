#ifndef TOREN_H
#define TOREN_H

#include <string>
#include <iostream>
 class toren
{
public:
    toren(  std::string soort_vuurwapen, std::string tekst,int damage, int tijd_damage, int bereik, int level, int geld, int health  );

 virtual ~toren();
    virtual void schiet (int aantal)=0 ;

protected:
    // de variabelen die een toren moet hebben
    //deze staan op protected omdat deze een keer worden meegegeven en erna nietmeer veranderbaar moeten zijn.
    std::string soort_vuurwapen;
    std::string tekst;
    int damage;
    int tijd_damage;
    int bereik;
    int health;
    int level;
    int geld;



};

#endif // TOREN_H
