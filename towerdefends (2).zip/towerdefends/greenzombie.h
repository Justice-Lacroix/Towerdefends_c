#ifndef GREENZOMBIE_H
#define GREENZOMBIE_H
#include "monsters.h"

class greenzombie:public monsters
{
public:
    greenzombie();
    ~greenzombie();
    void talk() ;
};

#endif // GREENZOMBIE_H
