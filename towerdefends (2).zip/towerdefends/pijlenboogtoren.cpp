// pijlenboogtoren.cpp
#include "pijlenboogtoren.h"
#include <iostream>

pijlenboogtoren::pijlenboogtoren() : toren("pijl", "vuur met precisie", 10, 1, 5, 1, 100, 15)
{
    // Constructorlogica voor pijlenboogtoren, indien van toepassing
}

pijlenboogtoren::~pijlenboogtoren()
{
    // Voeg eventuele logica toe voor de destructor van de pijlenboogtorenklasse
}

void pijlenboogtoren::schiet(int aantal)
{
    for (int i = 0; i < aantal; i++)
    {
        std::cout << soort_vuurwapen << std::endl;
    }
}
