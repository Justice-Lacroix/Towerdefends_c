#include "monsters.h"

// Constructor
monsters::monsters(int hp, bool leven, int speed) : hp(hp), leven(leven), speed(speed) {}

// Destructor
monsters::~monsters() {
    // Perform any necessary cleanup in the destructor
}

// Pure virtual function, needs to be implemented by derived classes
void monsters::talk() {
    // Implementation is not provided in the base class
    // Derived classes must override this function
    // (or remain abstract if they don't provide an implementation)
}
