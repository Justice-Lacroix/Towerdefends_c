// pijlenboogtoren.h
#ifndef PIJLENBOOGTOREN_H
#define PIJLENBOOGTOREN_H

#include "toren.h"

class pijlenboogtoren : public toren
{
public:
    void setSoortVuurwapen(const std::string& nieuweSoort) {
        soort_vuurwapen = nieuweSoort;
    }
    // Constructor met standaardwaarden voor attributen
    pijlenboogtoren();
    // Destructor
    ~pijlenboogtoren();
   virtual void schiet(int aantal) override;
};

#endif // PIJLENBOOGTOREN_H
